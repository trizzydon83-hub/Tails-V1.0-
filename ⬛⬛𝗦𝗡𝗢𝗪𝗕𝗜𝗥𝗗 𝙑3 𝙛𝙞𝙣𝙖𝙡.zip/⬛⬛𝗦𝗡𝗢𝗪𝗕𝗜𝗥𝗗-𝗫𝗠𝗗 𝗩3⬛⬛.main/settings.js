const settings = {
  packname: 'SNOWBIRD',
  author: '‎',
  botName: "𝙎𝙉𝙊𝙒𝘽𝙄𝙍𝘿",
  botOwner: '𝙋𝙪𝙗𝙡𝙞𝙘', // Your name
  ownerNumber: '263780145644', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "⬛⬛𝗦𝗡𝗢𝗪𝗕𝗜𝗥𝗗-𝗫𝗠𝗗 𝗩3⬛⬛   𝙏𝙃𝙀 𝘽𝙀𝙎𝙏 𝙒𝘼 𝘽𝙊𝙏 I𝙄𝙉 𝙕𝙄𝙈𝘽𝘼𝘽𝙒𝙀🇿🇼",
  version: "3.0.0",
};

module.exports = settings;
